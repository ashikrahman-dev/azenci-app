import SubPageHeader from "../../Components/SubPageHeader/SubPageHeader";

const About = () => {
    return (
        <div>
            <SubPageHeader
                pageTitle="About"
            />
        </div>
    );
};

export default About;